
close all
clear
load('poti_kurve.mat');
%Target Rotation travel vector:
%1 value for every integer percent
rot_travel_int = linspace(0,100,51);

% Ensure that the maximum of the curve is 1
out_vol = out_vol/max(out_vol);

out_vol_int = interp1(rot_travel, out_vol, rot_travel_int, 'linear');

%Fill end and start to eliminate NaN
out_vol_int(end) = out_vol_int(end-1);
out_vol_int(1) = 0;

% out_vol_int = out_vol_int/100 + 10e-3;
% out_vol_int = out_vol_int/max(out_vol_int);

figure
plot(rot_travel, out_vol);
hold on
plot(rot_travel_int, out_vol_int);
hold off
legend('raw data', 'interpolated data');

Vref = 1.8;
R31 = 100e3;
Roff = 1e3;

I = Vref/(R31 + Roff);
adc_volt = I*(out_vol_int * R31 + Roff);

%Calculate ADC Value from adc_volt
out_adc_val = adc_volt*1024/Vref;

%Round to Integers
out_adc_val = round(out_adc_val ,0);

%The Maximum detectable ADC-Value is Vref - LSB
%Limit the maximum adc_value to 1023
out_adc_val(find(out_adc_val == 1024)) = 1023;

%Transpose
rot_travel_int = rot_travel_int';
out_adc_val = out_adc_val';

figure;
plot(rot_travel_int, out_adc_val);
int = table(rot_travel_int, out_adc_val);
writetable(int, 'poti_curve_int.xlsx');